﻿Function Invoke-CTXOEPowerShellCommon ([Xml.XmlElement]$Params) {
    Try {
        If ($Params.value -is [System.Xml.XmlElement]) {
            Invoke-Expression -Command $Params.value.InnerText
        } Else {
            Invoke-Expression -Command $Params.value
        }
        
    } Catch {
        $Global:CTXOE_Result = $False;
        $Global:CTXOE_Details = "Unexpected crash of PowerShell code, error message: $($_.Exception)"
    }
}
Function Invoke-CTXOEPowerShellExecute ([Xml.XmlElement]$Params) {
    # Can only assume that system was changed.
    $Global:CTXOE_SystemChanged = $true;
    Invoke-CTXOEPowerShellCommon -Params $Params
}

Function Invoke-CTXOEPowerShellAnalyze ([Xml.XmlElement]$Params) {
    Invoke-CTXOEPowerShellCommon -Params $Params
}

Function Invoke-CTXOEPowerShellRollback ([Xml.XmlElement]$Params) {
    Invoke-CTXOEPowerShellCommon -Params $Params
}